package claseInterfaces;

import javax.swing.JOptionPane;

public class SegundoEjercicio {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Su ordenador tiene un ransomware", "Error grave", JOptionPane.INFORMATION_MESSAGE);
	}
}
