package claseInterfaces;

import javax.swing.JOptionPane;

public class PrimerEjercicio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre = "Juani";
		JOptionPane.showMessageDialog(null, "Bienvenido " + nombre);
	}

}
