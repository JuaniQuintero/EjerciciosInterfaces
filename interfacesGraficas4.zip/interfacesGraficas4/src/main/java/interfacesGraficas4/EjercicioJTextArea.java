package interfacesGraficas4;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import java.awt.BorderLayout;
import javax.swing.JLabel;

public class EjercicioJTextArea extends JFrame{
	public EjercicioJTextArea() {
		
		JTextArea textArea = new JTextArea();
		getContentPane().add(textArea, BorderLayout.CENTER);
		
		JLabel lblNewLabel = new JLabel("Comentario:");
		getContentPane().add(lblNewLabel, BorderLayout.NORTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			EjercicioJTextArea ventana = new EjercicioJTextArea();
			ventana.setVisible(true);
			ventana.setSize(300,100);
		});
	}

}
