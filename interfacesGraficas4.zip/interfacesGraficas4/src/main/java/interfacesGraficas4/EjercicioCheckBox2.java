package interfacesGraficas4;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.JCheckBox;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EjercicioCheckBox2 extends JFrame{
	private boolean selected1, selected2;
	public EjercicioCheckBox2() {
		selected1 = false;
		selected2 = false;
		JCheckBox check1 = new JCheckBox("Aceptar terminos y condiciones");
		getContentPane().add(check1, BorderLayout.CENTER);
		
		check1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!selected1) {
					mostrarJOP(true);
					selected1 = true;
				}else {
					selected1 = false;
				}
			}
		});
		
		
		
		JCheckBox check2 = new JCheckBox("Desea recibir publicidad");
		check2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!selected2) {
					mostrarJOP(false);
					selected2 = true;
				}else {
					selected2 = false;
				}
			}
		});
		
		getContentPane().add(check2, BorderLayout.EAST);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	public void mostrarJOP(boolean check1) {
		String texto="";
		if(check1) {
			texto = "Has aceptado los términos y condiciones";
		}else {
			texto = "Has aceptado recibir publicidad";
		}
		JOptionPane.showMessageDialog(this, texto, "Datos",JOptionPane.ERROR_MESSAGE);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			EjercicioCheckBox2 ventana = new EjercicioCheckBox2();
			ventana.setVisible(true);
			ventana.setSize(400,100);
		});
	}

}
