package interfacesGraficas4;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;

import java.awt.BorderLayout;
import javax.swing.ButtonGroup;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class EjercicioRadioButton2 extends JFrame{
	private final ButtonGroup buttonGroup = new ButtonGroup();
	public EjercicioRadioButton2() {
		
		JRadioButton opcion1 = new JRadioButton("Pastilla Azul");
		
		opcion1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				mostrarJOP(true);
			}
		});
		
		buttonGroup.add(opcion1);
		getContentPane().add(opcion1, BorderLayout.WEST);
		
		JRadioButton opcion2 = new JRadioButton("Pastilla Roja");
		opcion2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				mostrarJOP(false);
			}
		});
		buttonGroup.add(opcion2);
		getContentPane().add(opcion2, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void mostrarJOP(boolean pastillaA) {
		String texto="";
		if(pastillaA) {
			texto = "Has elegido la opción azul, quedate en tu mundo de fantasía";
		}else {
			texto = "Has elegido la opción roja, te contaré la verdad sobre matrix";
		}
		JOptionPane.showMessageDialog(this, texto, "Datos",JOptionPane.ERROR_MESSAGE);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			EjercicioRadioButton2 ventana = new EjercicioRadioButton2();
			ventana.setVisible(true);
			ventana.setSize(300,100);
		});
	}

}
