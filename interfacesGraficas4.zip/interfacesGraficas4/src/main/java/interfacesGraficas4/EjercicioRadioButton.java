package interfacesGraficas4;

import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;

import java.awt.BorderLayout;
import javax.swing.ButtonGroup;

public class EjercicioRadioButton extends JFrame{
	private final ButtonGroup buttonGroup = new ButtonGroup();
	public EjercicioRadioButton() {
		
		JRadioButton opcion1 = new JRadioButton("Opcion1");
		buttonGroup.add(opcion1);
		getContentPane().add(opcion1, BorderLayout.WEST);
		
		JRadioButton opcion2 = new JRadioButton("opcion2");
		buttonGroup.add(opcion2);
		getContentPane().add(opcion2, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			EjercicioRadioButton ventana = new EjercicioRadioButton();
			ventana.setVisible(true);
			ventana.setSize(300,100);
		});
	}

}
