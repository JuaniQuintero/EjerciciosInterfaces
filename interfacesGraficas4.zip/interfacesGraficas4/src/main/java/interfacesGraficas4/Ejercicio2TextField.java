package interfacesGraficas4;

import javax.swing.JFrame;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import java.awt.Insets;

public class Ejercicio2TextField extends JFrame {
	private JTextField campoNombre;
	private JTextField campoEdad;
	private JTextField campoDireccion;
	private JTextField campoProvincia;
	private JTextField campoCiudad;
	
	public Ejercicio2TextField() {
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{1.0, 0.0, 0.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		getContentPane().setLayout(gridBagLayout);
		
		JLabel textoNombre = new JLabel("Nombre");
		GridBagConstraints gbc_textoNombre = new GridBagConstraints();
		gbc_textoNombre.insets = new Insets(0, 0, 5, 5);
		gbc_textoNombre.gridx = 1;
		gbc_textoNombre.gridy = 1;
		getContentPane().add(textoNombre, gbc_textoNombre);
		
		campoNombre = new JTextField();
		GridBagConstraints gbc_campoNombre = new GridBagConstraints();
		gbc_campoNombre.fill = GridBagConstraints.HORIZONTAL;
		gbc_campoNombre.insets = new Insets(0, 0, 5, 5);
		gbc_campoNombre.gridx = 4;
		gbc_campoNombre.gridy = 1;
		getContentPane().add(campoNombre, gbc_campoNombre);
		campoNombre.setColumns(10);
		
		JLabel textoEdad = new JLabel("Edad");
		GridBagConstraints gbc_textoEdad = new GridBagConstraints();
		gbc_textoEdad.insets = new Insets(0, 0, 5, 5);
		gbc_textoEdad.gridx = 1;
		gbc_textoEdad.gridy = 2;
		getContentPane().add(textoEdad, gbc_textoEdad);
		
		campoEdad = new JTextField();
		GridBagConstraints gbc_campoEdad = new GridBagConstraints();
		gbc_campoEdad.anchor = GridBagConstraints.EAST;
		gbc_campoEdad.insets = new Insets(0, 0, 5, 5);
		gbc_campoEdad.gridx = 4;
		gbc_campoEdad.gridy = 2;
		getContentPane().add(campoEdad, gbc_campoEdad);
		campoEdad.setColumns(10);
		
		JLabel textoDireccion = new JLabel("Direccion");
		GridBagConstraints gbc_textoDireccion = new GridBagConstraints();
		gbc_textoDireccion.insets = new Insets(0, 0, 5, 5);
		gbc_textoDireccion.gridx = 1;
		gbc_textoDireccion.gridy = 3;
		getContentPane().add(textoDireccion, gbc_textoDireccion);
		
		campoDireccion = new JTextField();
		GridBagConstraints gbc_campoDireccion = new GridBagConstraints();
		gbc_campoDireccion.fill = GridBagConstraints.HORIZONTAL;
		gbc_campoDireccion.insets = new Insets(0, 0, 5, 5);
		gbc_campoDireccion.gridx = 4;
		gbc_campoDireccion.gridy = 3;
		getContentPane().add(campoDireccion, gbc_campoDireccion);
		campoDireccion.setColumns(10);
		
		JLabel textoProvincia = new JLabel("Provincia");
		GridBagConstraints gbc_textoProvincia = new GridBagConstraints();
		gbc_textoProvincia.insets = new Insets(0, 0, 5, 5);
		gbc_textoProvincia.gridx = 1;
		gbc_textoProvincia.gridy = 4;
		getContentPane().add(textoProvincia, gbc_textoProvincia);
		
		campoProvincia = new JTextField();
		GridBagConstraints gbc_campoProvincia = new GridBagConstraints();
		gbc_campoProvincia.fill = GridBagConstraints.HORIZONTAL;
		gbc_campoProvincia.insets = new Insets(0, 0, 5, 5);
		gbc_campoProvincia.gridx = 4;
		gbc_campoProvincia.gridy = 4;
		getContentPane().add(campoProvincia, gbc_campoProvincia);
		campoProvincia.setColumns(10);
		
		JLabel textoCiudad = new JLabel("Ciudad");
		GridBagConstraints gbc_textoCiudad = new GridBagConstraints();
		gbc_textoCiudad.insets = new Insets(0, 0, 5, 5);
		gbc_textoCiudad.gridx = 1;
		gbc_textoCiudad.gridy = 5;
		getContentPane().add(textoCiudad, gbc_textoCiudad);
		
		campoCiudad = new JTextField();
		GridBagConstraints gbc_campoCiudad = new GridBagConstraints();
		gbc_campoCiudad.insets = new Insets(0, 0, 5, 5);
		gbc_campoCiudad.fill = GridBagConstraints.HORIZONTAL;
		gbc_campoCiudad.gridx = 4;
		gbc_campoCiudad.gridy = 5;
		getContentPane().add(campoCiudad, gbc_campoCiudad);
		campoCiudad.setColumns(10);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			Ejercicio2TextField ventana = new Ejercicio2TextField();
			ventana.setVisible(true);
			ventana.setSize(500,500);
		});
	}

}
