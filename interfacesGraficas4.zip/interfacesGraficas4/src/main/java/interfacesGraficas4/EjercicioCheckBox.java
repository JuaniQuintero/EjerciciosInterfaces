package interfacesGraficas4;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.JCheckBox;
import java.awt.BorderLayout;

public class EjercicioCheckBox extends JFrame{
	public EjercicioCheckBox() {
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Aceptar terminos y condiciones");
		getContentPane().add(chckbxNewCheckBox, BorderLayout.CENTER);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(() -> {
			EjercicioCheckBox ventana = new EjercicioCheckBox();
			ventana.setVisible(true);
			ventana.setSize(300,100);
		});
	}

}
